# -*- coding:utf-8 -*-

img_cfg  = {
 'img_dir' : '/Users/lixingyun/work/private/image/img/'
}
