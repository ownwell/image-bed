# -*- coding:utf-8 -*-
import json,sys
import img_config as config

import time
import subprocess
import os
from workflow import Workflow

import clipboard

img_dir =  config.img_cfg['img_dir'] 

CLIPBOARD_EXCEPTIONS = (
    clipboard.WriteFileError,
    clipboard.FileTypeUnsupportedError,
    clipboard.NotImageError
)


imgUrl = ""

def timestamp_to_date(time_stamp, format_string="%Y-%m-%d-%H-%M-%S"):
    time_array = time.localtime(time_stamp)
    str_date = time.strftime(format_string, time_array)
    return str_date

def _convert_to_png(src_path, dest_path):
    """转换图片格式为png

    :param src_path: 源文件
    :param dest_path: 目标文件
    """
    os.system('sips -s format png {} --out {}'.format(src_path, dest_path))
    os.remove(src_path)

def saveClipboardImg():
    global imgUrl

    try:
        img_path = clipboard.get_pasteboard_img_path()
    except CLIPBOARD_EXCEPTIONS as error:
        # notice(str(error))
        pass
        return
    notice(str(img_path))
    file_name = os.path.split(img_path)[-1]
    file_type = file_name.split('.')[-1]
    if file_type == 'tiff':
        date = int(time.time())
        now = timestamp_to_date(date)
        filename =  str(now) 
        new_img_path = '{}{}.png'.format(img_dir, filename)
        imgUrl = '{}{}.png'.format('https://raw.githubusercontent.com/ownwell/image-bed/master/img/', filename)
        notice(imgUrl)

        # tiff --> png
        _convert_to_png(img_path, new_img_path)
        img_path = new_img_path
    else:
        name = img_path.split("/")[-1]

        imgUrl = '{}{}'.format('https://raw.githubusercontent.com/ownwell/image-bed/master/img/', name)



    # from PIL import Image
    # if isinstance(im, Image.Image):
    #     global imgUrl

    #     print(im.format, im.size, im.mode)
    #     date = int(time.time())
    #     now = timestamp_to_date(date)
    #     filename =  str(now) + ".jpg"
    #     imgUrl = "https://github.com/ownwell/image-bed/raw/master/"+filename
    #     notice(imgUrl)
    #     im.save(path +  filename, im.format)
    #     width, height = im.size
    #     pix = im.load()
    
    # else:
    #     notice("not image")
    # pass
def pullToGithub():
    cmd = '''cd ''' + img_dir + ''' ;git add .;git commit -m "blog_img";git push origin master
    '''
    subprocess.call(cmd, shell=True)

def write_to_pasteboard(text):
    """内容写入剪贴板

    :param text: 写入内容
    """
    os.system('echo \'{}\' | pbcopy'.format(text))


def print_pasteboard_content():
    """从剪贴板打印出内容"""
    write_command = (
        'osascript -e \'tell application '
        '"System Events" to keystroke "v" using command down\''
    )
    os.system(write_command)


def notice(msg, title=''):
    """通知 
    :param msg: 通知消息
    :param title: 通知标题
    """
    pass
    os.system('osascript -e \'display notification "{}" with title "{}"\''.format(msg, title))


def main(wf):

    saveClipboardImg()
    pullToGithub()
    notice(imgUrl)
    md_img = '![]({})'.format(imgUrl)
    write_to_pasteboard(md_img)
    print_pasteboard_content();

    # notice("1")
    # saveClipboardImg()
    # write_to_pasteboard("nihao")
    # print_pasteboard_content()

if __name__ == '__main__':
    wf = Workflow(libraries=['./lib'])
    sys.exit(wf.run(main))
    


